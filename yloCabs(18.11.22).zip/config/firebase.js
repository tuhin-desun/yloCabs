import * as firebase from "firebase";

const firebaseConfig = {
	apiKey: "AIzaSyCvWoLAkSh4Gi-vZEawcGRP9mts_Qt6V2s",
	authDomain: "ylocab-2e072.firebaseapp.com",
	databaseURL: "https://ylocab-2e072-default-rtdb.firebaseio.com",
	projectId: "ylocab-2e072",
	storageBucket: "ylocab-2e072.appspot.com",
	messagingSenderId: "131281460665",
	appId: "1:131281460665:web:473e41c47e8691729a2a68",
	measurementId: "G-SZYJ0WETSS"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);


export default firebase;
